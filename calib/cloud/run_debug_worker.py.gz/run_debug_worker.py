from kubernetes import client, config

import cloud_calib_config as cfg

# Load kubeconfig
config.load_kube_config(config_file="~/.kube/cditest3.yaml")
core_v1 = client.CoreV1Api()

# Define the container
container = client.V1Container(
    name="laser-polio debug-container",
    #image="ubuntu",  # Use any image with bash/sleep
    image=cfg.image,
    command=["sleep", "infinity"],
    resources=client.V1ResourceRequirements(requests={"cpu": "1"}, limits={"cpu": "1"}),
)

# Define the pod
pod_spec = client.V1PodSpec(
    containers=[container],
    restart_policy="Never",
    node_selector={"agentpool": "highcpu"},
    tolerations=[client.V1Toleration(key="nodepool", operator="Equal", value="highcpu", effect="NoSchedule")],
    image_pull_secrets=[client.V1LocalObjectReference(name="idmodregcred3")],
)

pod = client.V1Pod(
    api_version="v1",
    kind="Pod",
    metadata=client.V1ObjectMeta(name="laser-polio debug-pod"),
    spec=pod_spec,
)

# Create the pod
try:
    response = core_v1.create_namespaced_pod(namespace="default", body=pod)  # Change namespace if needed
    print(f"✅ Pod {response.metadata.name} created successfully.")
except client.exceptions.ApiException as e:
    print(f"❌ Error creating the pod: {e}")
